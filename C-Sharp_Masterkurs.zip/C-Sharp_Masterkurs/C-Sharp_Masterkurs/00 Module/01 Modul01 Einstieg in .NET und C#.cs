﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Masterkurs.Module
{
    public class Modul01
    {
        public Modul01()
        {
        }
        public void Einstieg()
        {
            Console.WriteLine("Hallo Welt!");
        }

    }
}