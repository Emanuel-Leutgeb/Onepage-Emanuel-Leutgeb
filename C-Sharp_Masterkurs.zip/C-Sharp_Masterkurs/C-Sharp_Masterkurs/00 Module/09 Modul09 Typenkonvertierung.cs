﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Masterkurs.Module
{
    public class Modul09
    {
        public Modul09()
        {
        }
        public void Typenkonvertierung()
        {
            /*
            //Impliziete Konvertierung (Automatisch)
            double double1 = 123.321;
            //float float1 = double1;       //funtioniert nicht, da Datenverlust!
                
            float float1x = 123.32F;
            double double1x = float1x;      //funktioniert, da kein Datenverlust!

            //Expliziete Konvertierung (Manuell) 
            double double2 = 213.347532672;
            float float2 = (float)double2;  //"Cast Operator"

            //Hilfsklassen zum Konvertieren
            //float2 = Convert.ToSingle(double2);

            Console.WriteLine(float2);
            */
        }
    }
}