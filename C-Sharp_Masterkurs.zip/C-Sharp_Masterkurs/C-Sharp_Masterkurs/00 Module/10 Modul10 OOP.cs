﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_Sharp_Masterkurs.Modul10_OOP;

namespace C_Sharp_Masterkurs.Module
{
    public class Modul10
    {
        public Modul10()
        { 
        }
        public void OOP()
        {
            Program_OOP program_OOP = new Program_OOP();
            program_OOP.Modul10();
        }
    }
}