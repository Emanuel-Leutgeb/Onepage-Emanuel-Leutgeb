﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_Sharp_Masterkurs.Modul12_AbstrakteKlassenUndMethoden;

namespace C_Sharp_Masterkurs.Module
{
    public class Modul12
    {
        public Modul12()
        {
        }
        public void AbstrakteKlassenUndMethoden()
        {
            Program_AbstrakteKlassenUndMethoden program_AbstrakteKlassenUndMethoden = new Program_AbstrakteKlassenUndMethoden();
            program_AbstrakteKlassenUndMethoden.Modul12();
        }
    }
}