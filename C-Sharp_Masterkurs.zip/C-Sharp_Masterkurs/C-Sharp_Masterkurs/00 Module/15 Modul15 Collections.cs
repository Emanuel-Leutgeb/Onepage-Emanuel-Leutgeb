﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_Sharp_Masterkurs.Modul15_Collections;

namespace C_Sharp_Masterkurs.Module
{
    public class Modul15
    {
        public Modul15()
        {
        }
        public void Collections()
        {
            Program_Collections program_Collections = new Program_Collections();
            program_Collections.Modul15();
        }
    }
}