﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Masterkurs.Module
{
    public class Modul20
    {
        public Modul20()
        {
        }
        public void MathKlassen()
        {
            Console.WriteLine(Math.Abs(-55));
            Console.WriteLine(Math.Pow(5, 2));
            Console.WriteLine(Math.PI);

            // Siehe Dokumentation bei MSDN (https://docs.microsoft.com/de-at/dotnet/csharp/)
        }
    }
}