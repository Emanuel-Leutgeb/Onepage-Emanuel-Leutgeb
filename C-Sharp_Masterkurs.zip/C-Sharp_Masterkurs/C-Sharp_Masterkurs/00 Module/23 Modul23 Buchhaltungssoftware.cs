﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_Sharp_Masterkurs.Modul23_Buchhaltungssoftware;

namespace C_Sharp_Masterkurs.Module
{
    public class Modul23
    {
        public Modul23()
        {
        }
        public void Buchhaltungssoftware()
        {
            Program_Buchhaltungssoftware program_Buchhaltungssoftware = new Program_Buchhaltungssoftware();
            program_Buchhaltungssoftware.Modul23();
        }
    }
}