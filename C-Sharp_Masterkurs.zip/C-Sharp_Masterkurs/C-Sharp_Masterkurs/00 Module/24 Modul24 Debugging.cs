﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Masterkurs.Module
{
    public class Modul24
    {
        public Modul24()
        {
        }
        public void Debugging()
        {

        }
    }
}