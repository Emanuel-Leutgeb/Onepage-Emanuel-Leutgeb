﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_Sharp_Masterkurs.Modul25_LINQ;

namespace C_Sharp_Masterkurs.Module
{
    public class Modul25
    {
        public Modul25()
        {
        }
        public void LINQ()
        {
            Program_LINQ program_LINQ = new Program_LINQ();
            program_LINQ.Modul25();
        }
    }
}