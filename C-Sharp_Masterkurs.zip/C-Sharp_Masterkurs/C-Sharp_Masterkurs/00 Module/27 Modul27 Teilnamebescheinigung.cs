﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Masterkurs.Module
{
    public class Modul27
    {
        public Modul27()
        {
        }
        public void Teilnahmebescheinigung()
        {
            Console.WriteLine("                 Hurra!");

            Console.WriteLine("Du hast den C# Masterkurs erfolgreich absolviert.");
            
        }
    }
}