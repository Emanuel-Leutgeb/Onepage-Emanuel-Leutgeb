﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_Sharp_Masterkurs.Module;

namespace C_Sharp_Masterkurs
{
    class Program_Main
    {
        static void Main(string[] args)
        {
            /*
            Modul01 modul01 = new Modul01();
            modul01.Einstieg();
            
            Modul02 modul02 = new Modul02();
            modul02.VariablenUndDatentypen();
            
            Modul03 modul03 = new Modul03();
            modul03.Operatoren();
            
            Modul04 modul04 = new Modul04();
            modul04.Methoden();
            
            Modul05 modul05 = new Modul05();
            modul05.Fallunterscheidungen();
            
            Modul06 modul06 = new Modul06();
            modul06.Arrays();
            
            Modul07 modul07 = new Modul07();
            modul07.Schleifen();
            
            Modul08 modul08 = new Modul08();
            modul08.Hangman();
            
            Modul09 modul09 = new Modul09();
            modul09.Typenkonvertierung();
            
            Modul10 modul10 = new Modul10();
            modul10.OOP();
           
            Modul11 modul11 = new Modul11();
            modul11.Interfaces();
            
            Modul12 modul12 = new Modul12();
            modul12.AbstrakteKlassenUndMethoden();
            
            Modul13 modul13 = new Modul13();
            modul13.Polymorphie();
            
            Modul14 modul14 = new Modul14();
            modul14.StrukturenUndEnums();
            
            Modul15 modul15 = new Modul15();
            modul15.Collections();
            
            Modul16 modul16 = new Modul16();
            modul16.Generics();
            
            Modul17 modul17 = new Modul17();
            modul17.Delegaten();
            
            Modul18 modul18 = new Modul18();
            modul18.Events();
            
            Modul19 modul19 = new Modul19();
            modul19.TryCatch();
            
            Modul20 modul20 = new Modul20();
            modul20.MathKlassen();
            
            Modul21 modul21 = new Modul21();
            modul21.RandomKlassen();
            
            Modul22 modul22 = new Modul22();
            modul22.SystemIO();
            
            Modul23 modul23 = new Modul23();
            modul23.Buchhaltungssoftware();
            
            Modul24 modul24 = new Modul24();
            modul24.Debugging();
            
            Modul25 modul25 = new Modul25();
            modul25.LINQ();
            
            Modul26 modul26 = new Modul26();
            modul26.Zahlensysteme();
            
            Modul27 modul27 = new Modul27();
            modul27.Teilnahmebescheinigung();
            */

            Console.ReadKey();
            Console.Clear();
        }
    }
}