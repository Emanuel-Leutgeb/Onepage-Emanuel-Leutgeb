﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Masterkurs.Modul10_OOP
{
    static class Mathe
    {
        public static double RechteckFläche(double breite, double höhe)
        {
            return breite * höhe;
        }
    }
}
