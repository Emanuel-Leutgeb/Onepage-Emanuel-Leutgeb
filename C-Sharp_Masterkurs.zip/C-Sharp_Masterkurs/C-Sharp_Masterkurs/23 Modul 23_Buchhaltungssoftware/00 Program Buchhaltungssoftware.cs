﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Masterkurs.Modul23_Buchhaltungssoftware
{
    public class Program_Buchhaltungssoftware
    {
        public Program_Buchhaltungssoftware()
        {
        }
        public void Modul23()
        {
            Menu startMenu = new StartMenu();
        }
    }
}
