﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Masterkurs.Modul25_LINQ
{
    public class Program_LINQ
    {
        public Program_LINQ()
        {
        }
        public void Modul25()
        {
            //Delegates delegates = new Delegates();

            //Anonyme_Methoden_und_Lambda_Ausdrücke anonyme_Methoden_Und_Lambda_Ausdrücke = new Anonyme_Methoden_und_Lambda_Ausdrücke();

            //Extension_Methods extension_Methods = new Extension_Methods();

            //LINQ linq = new LINQ();

            //Methoden_und_Query_Syntax methoden_Und_Query_Syntax = new Methoden_und_Query_Syntax();

            //Where_Methode where_Methode = new Where_Methode();

            //OfType_Methode ofType_Methode = new OfType_Methode();

            //OrderBy_und_ThenBy orderBy_Und_ThenBy = new OrderBy_und_ThenBy();

            //GroupBy groupBy = new GroupBy();

            //Komplexere_Abfragen_mit_Aufrufketten komplexere_Abfragen_Mit_Aufrufketten = new Komplexere_Abfragen_mit_Aufrufketten();

            //Einfache_Aggregationsoperatoren einfache_Aggregationsoperatoren = new Einfache_Aggregationsoperatoren();

            //Einfache_Aggregationsoperatoren einfache_Aggregationsoperatoren = new Einfache_Aggregationsoperatoren();

            //Aggregate_Methode aggregate_Methode = new Aggregate_Methode();

            //Join join = new Join();

            //Join_mit_der_Methoden_Syntax join_Mit_Der_Methoden_Syntax = new Join_mit_der_Methoden_Syntax();

            //Mehr_als_2_Datenquellen_miteinander_verknüpfen mehr_Als_2_Datenquellen_Miteinander_Verknüpfen = new Mehr_als_2_Datenquellen_miteinander_verknüpfen();

            //GroupJoin groupJoin = new GroupJoin();

            //Select_Operator select_Operator = new Select_Operator();

            //Element_Operatoren element_Operatoren = new Element_Operatoren();

            //Empty_Range_und_Repeat empty_Range_Und_Repeat = new Empty_Range_und_Repeat();

            //Concat_Methode concat_Methode = new Concat_Methode();

            //Distinct_Methode distinct_Methode = new Distinct_Methode();

            //Expect_Methode expect_Methode = new Expect_Methode();

            //Intersect_Methode intersect_Methode = new Intersect_Methode();

            //Union_Methode union_Methode = new Union_Methode();

            //Skip_und_Take_Methode skip_Und_Take_Methode = new Skip_und_Take_Methode();

            //Sequenzen_Konvertieren sequenzen_Konvertieren = new Sequenzen_Konvertieren();

            //Aufbau_einer_XML_Datei aufbau_Einer_XML_Datei = new Aufbau_einer_XML_Datei();

            //LINQ_to_XML lINQ_To_XML = new LINQ_to_XML();

            //XML_im_Code_generieren_speichern_und_laden xML_Im_Code_Generieren_Speichern_Und_Laden = new XML_im_Code_generieren_speichern_und_laden();

            //XML_Dateien_in_LINQ_abfragen xML_Dateien_In_LINQ_Abfragen = new XML_Dateien_in_LINQ_abfragen();

            //XML_Dateien_bearbeiten_mit_LINQ_to_XML xML_Dateien_Bearbeiten_Mit_LINQ_To_XML = new XML_Dateien_bearbeiten_mit_LINQ_to_XML();

            //Dauer_einer_Query_messen dauer_Einer_Query_Messen = new Dauer_einer_Query_messen();

            //Parallel_LINQ parallel_LINQ = new Parallel_LINQ();
        } 
    }
}
