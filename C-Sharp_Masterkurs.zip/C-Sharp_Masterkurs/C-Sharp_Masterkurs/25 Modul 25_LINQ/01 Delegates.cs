﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace C_Sharp_Masterkurs.Modul25_LINQ
{
    public class Delegates
    {
        public delegate double Calculate(double x, double y);

        public Delegates()
        {
            Calculate calc1 = new Calculate(Summation);
            Console.WriteLine(calc1(10, 3));

            Calculate calc2 = new Calculate(Subtraction);
            Console.WriteLine(calc2(10, 3));

            Calculate calc3 = new Calculate(Multiplication);
            Console.WriteLine(calc3(10, 3));

            Calculate calc4 = new Calculate(Division);
            Console.WriteLine(calc4(10, 3));

            Calculate calc5 = new Calculate(Modolo);
            Console.WriteLine(calc5(10, 3));
        }

        public static double Summation(double x, double y)
        {
            return x + y;
        }

        public static double Subtraction(double x, double y)
        {
            return x - y;
        }

        public static double Multiplication(double x, double y)
        {
            return x * y;
        }

        public static double Division(double x, double y)
        {
            return x / y;
        }

        public static double Modolo(double x, double y)
        {
            return x % y;
        }
    }
}
*/