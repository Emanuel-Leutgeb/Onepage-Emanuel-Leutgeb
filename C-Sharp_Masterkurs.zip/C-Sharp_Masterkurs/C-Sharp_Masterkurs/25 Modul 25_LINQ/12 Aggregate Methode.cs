﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace C_Sharp_Masterkurs.Modul25_LINQ
{
    public class Aggregate_Methode
    {
        public Aggregate_Methode()
        {
            int[] numbers = { 30, 40, 50, 60 };

            var result = numbers.Aggregate((currentValue, nextValue) => currentValue + nextValue);

            Console.WriteLine(result);

            //-------------------------------------------------------------------------------------

            string[] names = { "Tom", "Peter", "Emanuel", "Miriam" };

            var result1 = names.Aggregate((s1, s2) => s1 + ", " + s2);

            Console.WriteLine(result1);
        }
    }
}
*/