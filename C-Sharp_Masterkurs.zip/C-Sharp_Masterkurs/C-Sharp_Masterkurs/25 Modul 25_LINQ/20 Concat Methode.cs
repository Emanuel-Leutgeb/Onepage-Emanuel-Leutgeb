﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace C_Sharp_Masterkurs.Modul25_LINQ
{
    public class Concat_Methode
    {
        public Concat_Methode()
        {
            List<string> names1 = new List<string>();
            List<string> names2 = new List<string>();

            names1.Add("John");
            names1.Add("Emanuel");
            names1.Add("Michael");

            names2.Add("Sandra");
            names2.Add("Miriam");
            names2.Add("Elina");

            var allNames = names1.Concat(names2);

            var allNameStartingWithE = from name in allNames
                                       where name.ToLower()[0] == 'e'
                                       select name;

            foreach (string name in allNames)
            {
                Console.WriteLine(name);
            }

            foreach (string name in allNameStartingWithE)
            {
                Console.WriteLine(name);
            }
        }
    }
}
*/