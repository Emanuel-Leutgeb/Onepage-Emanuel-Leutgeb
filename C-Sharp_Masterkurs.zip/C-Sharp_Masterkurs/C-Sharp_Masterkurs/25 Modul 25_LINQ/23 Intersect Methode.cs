﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace C_Sharp_Masterkurs.Modul25_LINQ
{
    public class Intersect_Methode
    {
        public Intersect_Methode()
        {
            string[] names1 =
            {
                "Emanuel",
                "Miriam",
                "Hendrik",
                "Peter"
            };

            string[] names2 =
            {
                "Miriam",
                "Sandra",
                "Alina",
                "Emanuel"
            };

            var names3 = names1.Intersect(names2);

            foreach (string name in names3)
            {
                Console.WriteLine(name);
            }
        }
    }
}
*/