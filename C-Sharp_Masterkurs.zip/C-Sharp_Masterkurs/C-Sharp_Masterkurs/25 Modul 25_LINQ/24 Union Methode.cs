﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace C_Sharp_Masterkurs.Modul25_LINQ
{
    public class Union_Methode
    {
        public Union_Methode()
        {
            int[] numbers1 = { 1, 2, 3, 4, 5 };
            int[] numbers2 = { 5, 6, 7, 8, 9 };

            var numbers3 = numbers1.Union(numbers2);

            foreach(int number in numbers3)
            {
                Console.WriteLine(number);
            }
        }
    }
}
*/