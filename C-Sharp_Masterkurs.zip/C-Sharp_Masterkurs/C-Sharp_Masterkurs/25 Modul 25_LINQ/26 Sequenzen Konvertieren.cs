﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace C_Sharp_Masterkurs.Modul25_LINQ
{
    public class Sequenzen_Konvertieren
    {
        public Sequenzen_Konvertieren()
        {
            Customer[] customerArray =
            {
                new Customer(1, "Emanuel"),
                new Customer(1, "Emanuel"),
                new Customer(1, "Emanuel"),
                new Customer(1, "Emanuel")
            };

            var customerEnumerable1 = customerArray.AsEnumerable();

            var customerQueryable1 = customerArray.AsQueryable();

            var customerEnumerable2 = customerArray.Cast<Customer>();

            var customerList = customerArray.ToList();

            var customerArray2 = customerArray.ToArray();
        }
    }

    public class Customer
    {
        //Properties
        public int CustomerID { get; set; }
        public string Name { get; set; }

        //Constructor
        public Customer(int customerID, string name)
        {
            CustomerID = customerID;
            Name = name;
        }
    }
}
*/