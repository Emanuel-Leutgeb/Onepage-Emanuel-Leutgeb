
public class Main_String {

	public static void main(String[] args) {
		
		String hello = "Hello World!";
		String bye = "Good Bye!";
			
		System.out.println(hello);				
		System.out.println(bye);
				
		System.out.println(hello + " " + bye);
				
		hello = bye;
						
		System.out.println(hello);
			
		System.out.println(bye);
			
		System.out.println(hello + " " + bye);

	}

}
