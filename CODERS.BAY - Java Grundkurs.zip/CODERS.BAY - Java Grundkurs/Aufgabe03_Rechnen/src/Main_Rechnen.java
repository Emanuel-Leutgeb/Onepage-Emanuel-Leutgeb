
public class Main_Rechnen {

	public static void main(String[] args) {
		
		int num1 = 3;
		int num2 = 5;
		
		
		System.out.println();

		System.out.println("Zahl " + 1 + " / " + num1 + " = " + ((double)1 / (double)num1));
		
		System.out.println("Zahl " + 2 + " / " + num2 + " = " + ((double)2 / (double)num2));	
		
		System.out.println(num2 + " + " + num1 + " = " + (num1 + num2));
		
		System.out.println(num2 + " - " + num1 + " = " + (num2 - num1));
		
		System.out.println(num2 + " * " + num1 + " = " + (num1 * num2));
		
		System.out.println(num2 + " / " + num1 + " = " + ((double)num2 / (double)num1));
		
		System.out.println(num2 + " % " + num1 + " = " + (num2 % num1));
		
		int num3 = 5;
		num3++;
		System.out.println(num2 + "++ = " + num3);
		
		int num4 = 5;
		num4--;
		System.out.println(num2 + "-- = " + num4);
		
	}

}
