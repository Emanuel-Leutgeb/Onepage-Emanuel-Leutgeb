
public class Main_EinMalEins {

	public static void main(String[] args) {
		int num1 = 3;
		int num2 = 1;
		int result;

		result = num1 * num2;
		System.out.println(num1 + " * " + num2 + " = " + result);
		
		num2++;
		result = num1 * num2;
		System.out.println(num1 + " * " + num2 + " = " + result);
		
		num2++;
		result = num1 * num2;
		System.out.println(num1 + " * " + num2 + " = " + result);
		
		num2++;
		result = num1 * num2;
		System.out.println(num1 + " * " + num2 + " = " + result);
		
		num2++;
		result = num1 * num2;
		System.out.println(num1 + " * " + num2 + " = " + result);
		
		num2++;		
		result = num1 * num2;
		System.out.println(num1 + " * " + num2 + " = " + result);
		
		num2++;
		result = num1 * num2;
		System.out.println(num1 + " * " + num2 + " = " + result);
		
		num2++;
		result = num1 * num2;
		System.out.println(num1 + " * " + num2 + " = " + result);
		
		num2++;
		result = num1 * num2;
		System.out.println(num1 + " * " + num2 + " = " + result);
		
		num2++;
		result = num1 * num2;
		System.out.println(num1 + " * " + num2 + " = " + result);
		
	}

}
