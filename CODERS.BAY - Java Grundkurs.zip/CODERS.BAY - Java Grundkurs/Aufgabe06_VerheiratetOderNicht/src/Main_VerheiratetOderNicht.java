
public class Main_VerheiratetOderNicht {

	public static void main(String[] args) {

		boolean isMarried = true;
		
		if (isMarried == true) {
			System.out.println("You are married!");
		}	
		else if(isMarried == false) {
			System.out.println("You are not married!");
		}
		else {
			System.out.println("No currect input!");
		}
	}
}
