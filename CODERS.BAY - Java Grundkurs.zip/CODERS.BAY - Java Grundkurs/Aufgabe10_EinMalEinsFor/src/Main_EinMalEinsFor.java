
public class Main_EinMalEinsFor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = 1; i <= 10; i++) {

			for (int n = 1; n <= 10; n++) {
				System.out.println(i + (" + " + n + " = " + (i * n)));
			}
			System.out.println(" "+ i + "er Reihe");
		}		
	}

}
