
public class Main_Day2 {

	public static void main(String[] args) {
		/*
		//Relationale Operatoren
		
		byte a = 5;
		byte b = 3;
		boolean c;		
		
		c = a == b;
		System.out.println(c);
		
		c = a != b;
		System.out.println(c);
		
		c = a > b;
		System.out.println(c);
		
		c = a < b;
		System.out.println(c);
		
		c = a >= b;
		System.out.println(c);
		
		c = a <= b;
		System.out.println(c);
		*/
		//
		
	}

}
